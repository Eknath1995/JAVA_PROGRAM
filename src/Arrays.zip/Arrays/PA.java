package Arrays;

public class PA {

	public static void displayArray(int[]a) {
		
		for(int i=0; i<a.length; i++) {
			System.out.println(a[i]+" ");
		}
	}

}
