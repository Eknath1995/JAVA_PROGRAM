package Arrays;

public class insertionSort {
public static void main(String[] args) {
	
}
	public static void insertion(int a[][]) {
		for(int i=1; i<a.length; i++) {
			int key=a[i];
			int j=i-1;
		}
	}
}
